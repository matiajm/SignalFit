
  # Fitness Tracking App Design

  This is a code bundle for Fitness Tracking App Design. The original project is available at https://www.figma.com/design/0TKmcGh5XHz54NpZ6uW2O7/Fitness-Tracking-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  